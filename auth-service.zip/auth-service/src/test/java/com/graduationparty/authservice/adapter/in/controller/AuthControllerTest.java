package com.graduationparty.authservice.adapter.in.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.graduationparty.authservice.BaseIntegrationTest;
import com.graduationparty.authservice.domain.model.AccessToken;
import com.graduationparty.authservice.domain.model.User;
import com.graduationparty.authservice.domain.model.User.RoleUser;
import com.graduationparty.authservice.domain.port.in.UserUseCase;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

public class AuthControllerTest extends BaseIntegrationTest {

  @Autowired private ObjectMapper objectMapper;

  @MockBean private UserUseCase userUseCase;

  @Test
  void testSignup() throws Exception {
    User user = new User(null, "test", "test@test.com", "password", RoleUser.USER, null);

    User createdUser = new User("12345", "test", "test@test.com", null, RoleUser.USER, null);

    when(userUseCase.createUser(any(User.class))).thenReturn(createdUser);

    perform(
            MockMvcRequestBuilders.post("/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(user)))
        .andExpect(MockMvcResultMatchers.status().isCreated())
        .andExpect(MockMvcResultMatchers.jsonPath("$.id", Matchers.is("12345")))
        .andExpect(MockMvcResultMatchers.jsonPath("$.username", Matchers.is("test")))
        .andExpect(MockMvcResultMatchers.jsonPath("$.email", Matchers.is("test@test.com")));
  }

  @Test
  void testLogin() throws Exception {
    String username = "test";
    String password = "password";
    var token = new AccessToken("dummy-token");

    when(userUseCase.authenticate(username, password)).thenReturn(token);

    perform(
            MockMvcRequestBuilders.post("/auth/login")
                .param("username", username)
                .param("password", password))
        .andExpect(MockMvcResultMatchers.status().isOk());
  }
}
