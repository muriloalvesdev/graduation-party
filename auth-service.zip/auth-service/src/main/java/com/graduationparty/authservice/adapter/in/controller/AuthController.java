package com.graduationparty.authservice.adapter.in.controller;

import com.graduationparty.authservice.domain.model.AccessToken;
import com.graduationparty.authservice.domain.model.User;
import com.graduationparty.authservice.domain.port.in.UserUseCase;
import java.net.URI;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/auth")
public class AuthController {

  private final UserUseCase userUseCase;

  public AuthController(UserUseCase userUseCase) {
    this.userUseCase = userUseCase;
  }

  @PostMapping("/signup")
  public ResponseEntity<User> signup(@RequestBody User user) {
    User createdUser = userUseCase.createUser(user);
    URI location =
        ServletUriComponentsBuilder.fromCurrentRequest()
            .path("/{id}")
            .buildAndExpand(createdUser.id())
            .toUri();
    return ResponseEntity.created(location).body(createdUser);
  }

  @PostMapping("/login")
  public ResponseEntity<AccessToken> login(
      @RequestParam(name = "username") String username,
      @RequestParam(name = "password") String password) {
    return ResponseEntity.ok(userUseCase.authenticate(username, password));
  }
}
