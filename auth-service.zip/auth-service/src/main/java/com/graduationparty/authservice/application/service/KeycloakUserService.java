package com.graduationparty.authservice.application.service;

import com.graduationparty.authservice.adapter.out.response.Page;
import com.graduationparty.authservice.adapter.out.response.UserDTO;
import com.graduationparty.authservice.domain.model.AccessToken;
import com.graduationparty.authservice.domain.model.User;
import com.graduationparty.authservice.domain.port.in.UserUseCase;
import com.graduationparty.authservice.domain.port.out.UserRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class KeycloakUserService implements UserUseCase {

  private static final Logger LOG = LoggerFactory.getLogger(KeycloakUserService.class);

  private final UserRepository userRepository;

  public KeycloakUserService(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @Override
  @CircuitBreaker(name = "keycloak", fallbackMethod = "createUserFallback")
  public User createUser(User user) {
    validateUserCreation(user);
    return userRepository.create(user);
  }

  @Override
  @CircuitBreaker(name = "keycloak", fallbackMethod = "authenticateFallback")
  public AccessToken authenticate(String username, String password) {
    validateCredentials(username, password);
    return userRepository.authenticate(username, password);
  }

  @Override
  @CircuitBreaker(name = "keycloak", fallbackMethod = "findUserByIdFallback")
  public UserDTO findUserById(UUID id) {
    if (id == null) throw new IllegalArgumentException("ID não pode ser nulo");
    User user = userRepository.findById(id);
    if (user == null) throw new RuntimeException("Usuário não encontrado");
    return new UserDTO(user.id(), user.username(), user.email(), user.role(), user.profilePhoto());
  }

  @Override
  @CircuitBreaker(name = "keycloak", fallbackMethod = "findAllUsersFallback")
  public Page<UserDTO> findAllUsers(int page, int size) {
    if (page < 0 || size <= 0)
      throw new IllegalArgumentException("Parâmetros de paginação inválidos");
    int first = page * size;
    var users =
        userRepository.findAll(first, size).stream()
            .map(
                user ->
                    new UserDTO(
                        user.id(), user.username(), user.email(), user.role(), user.profilePhoto()))
            .toList();
    long total = userRepository.count();
    return new Page<>(users, page, size, total);
  }

  @Override
  @CircuitBreaker(name = "keycloak", fallbackMethod = "updateUserFallback")
  public User updateUser(UUID id, User user) {
    if (id == null) throw new IllegalArgumentException("ID não pode ser nulo");
    validateUserUpdate(user);
    return userRepository.update(id, user);
  }

  @Override
  @CircuitBreaker(name = "keycloak", fallbackMethod = "deleteUserFallback")
  public void deleteUser(UUID id) {
    if (id == null) throw new IllegalArgumentException("ID não pode ser nulo");
    userRepository.delete(id);
  }

  public User createUserFallback(User user, Throwable t) {
    LOG.error("Fallback: Falha ao criar usuário", t);
    throw new RuntimeException("Serviço indisponível, tente novamente mais tarde");
  }

  public AccessToken authenticateFallback(String username, String password, Throwable t) {
    LOG.error("Fallback: Falha ao autenticar usuário", t);
    throw new RuntimeException("Serviço de autenticação indisponível, tente novamente mais tarde");
  }

  public UserDTO findUserByIdFallback(UUID id, Throwable t) {
    LOG.error("Fallback: Falha ao buscar usuário por ID", t);
    throw new RuntimeException("Serviço indisponível, tente novamente mais tarde");
  }

  public Page<UserDTO> findAllUsersFallback(int page, int size, Throwable t) {
    LOG.error("Fallback: Falha ao listar usuários", t);
    throw new RuntimeException("Serviço indisponível, tente novamente mais tarde");
  }

  public User updateUserFallback(UUID id, User user, Throwable t) {
    LOG.error("Fallback: Falha ao atualizar usuário", t);
    throw new RuntimeException("Serviço indisponível, tente novamente mais tarde");
  }

  public void deleteUserFallback(UUID id, Throwable t) {
    LOG.error("Fallback: Falha ao remover usuário", t);
    throw new RuntimeException("Serviço indisponível, tente novamente mais tarde");
  }

  private void validateUserCreation(User user) {
    if (user == null) throw new IllegalArgumentException("Usuário não pode ser nulo");
    if (user.username() == null || user.username().isEmpty())
      throw new IllegalArgumentException("Username é obrigatório");
    if (user.email() == null || user.email().isEmpty())
      throw new IllegalArgumentException("Email é obrigatório");
    if (user.password() == null || user.password().isEmpty())
      throw new IllegalArgumentException("Password é obrigatório");
    if (user.role() == null) throw new IllegalArgumentException("Role é obrigatória");
  }

  private void validateCredentials(String username, String password) {
    if (username == null || username.isEmpty())
      throw new IllegalArgumentException("Username deve ser informado");
    if (password == null || password.isEmpty())
      throw new IllegalArgumentException("Password deve ser informado");
  }

  private void validateUserUpdate(User user) {
    if (user == null) throw new IllegalArgumentException("Usuário não pode ser nulo");
    if (user.username() == null || user.username().isEmpty())
      throw new IllegalArgumentException("Username é obrigatório");
    if (user.email() == null || user.email().isEmpty())
      throw new IllegalArgumentException("Email é obrigatório");
    if (user.role() == null) throw new IllegalArgumentException("Role é obrigatória");
  }
}
