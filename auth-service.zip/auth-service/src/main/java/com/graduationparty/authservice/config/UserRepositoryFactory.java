package com.graduationparty.authservice.config;

import com.graduationparty.authservice.adapter.out.keycloak.KeycloakUserRepository;
import com.graduationparty.authservice.domain.port.out.UserRepository;
import org.keycloak.admin.client.Keycloak;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UserRepositoryFactory {

  @Value("${auth.persistence.provider:keycloak}")
  private String persistenceProvider;

  @Value("${keycloak.realm}")
  private String realm;

  @Value("${keycloak.server-url}")
  private String serverUrl;

  @Value("${keycloak.resource}")
  private String clientId;

  @Value("${keycloak.credentials.secret}")
  private String clientSecret;

  @Bean
  public UserRepository userRepository(Keycloak keycloak) {
    switch (persistenceProvider.toLowerCase()) {
      case "keycloak":
        return new KeycloakUserRepository(keycloak, realm, serverUrl, clientId, clientSecret);
      default:
        throw new IllegalArgumentException(
            "Provedor de persistência desconhecido: " + persistenceProvider);
    }
  }
}
