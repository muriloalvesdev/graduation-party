package com.graduationparty.authservice.domain.model;

public record User(
    String id, String username, String email, String password, RoleUser role, String profilePhoto) {

  public enum RoleUser {
    ADMIN,
    USER
  }
}
