package com.graduationparty.authservice.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

/**
 * Filtro para logar informações de todas as requisições HTTP, autenticadas ou não. Registra IP,
 * URI, usuário (autenticado ou anônimo) e payload da requisição.
 */
@Component
public class LoggingFilter extends OncePerRequestFilter {

  private static final Logger logger = LoggerFactory.getLogger(LoggingFilter.class);

  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    ContentCachingRequestWrapper wrappedRequest = new ContentCachingRequestWrapper(request);
    ContentCachingResponseWrapper wrappedResponse = new ContentCachingResponseWrapper(response);

    String ip = request.getRemoteAddr();
    String method = request.getMethod();
    String uri = request.getRequestURI();

    logger.info("Requisição recebida: method={}, uri={}, ip={}", method, uri, ip);

    String requestPayload = getRequestPayload(wrappedRequest);
    if (requestPayload != null && !requestPayload.isEmpty()) {
      logger.info("Payload da requisição: {}", requestPayload);
    }

    filterChain.doFilter(wrappedRequest, wrappedResponse);

    String user = getAuthenticatedUser();
    logger.info(
        "Resposta enviada: uri={}, status={}, user={}",
        uri,
        wrappedResponse.getStatus(),
        user != null ? user : "anonymous");

    wrappedResponse.copyBodyToResponse();
  }

  /**
   * Obtém o usuário autenticado a partir do contexto de segurança.
   *
   * @return Nome do usuário autenticado ou null se não houver autenticação.
   */
  private String getAuthenticatedUser() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication != null
        && authentication.isAuthenticated()
        && !"anonymousUser".equals(authentication.getName())) {
      return authentication.getName();
    }
    return null;
  }

  /**
   * Obtém o payload da requisição.
   *
   * @param request Requisição envolvida.
   * @return Payload da requisição como string ou null se não houver payload.
   */
  private String getRequestPayload(ContentCachingRequestWrapper request) {
    try {
      byte[] content = request.getContentAsByteArray();
      if (content.length > 0) {
        return new String(content, StandardCharsets.UTF_8);
      }
    } catch (Exception e) {
      logger.error("Erro ao capturar o payload da requisição", e);
    }
    return null;
  }
}
