package com.graduationparty.authservice.adapter.in.controller;

import com.graduationparty.authservice.domain.model.User;
import com.graduationparty.authservice.domain.port.in.UserUseCase;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

  private final UserUseCase userUseCase;

  @Autowired
  public UserController(UserUseCase userUseCase) {
    this.userUseCase = userUseCase;
  }

  @GetMapping
  public ResponseEntity<?> getAllUsers(
      @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) {
    return ResponseEntity.ok(userUseCase.findAllUsers(page, size));
  }

  @GetMapping("/{id}")
  public ResponseEntity<?> getUserById(@PathVariable UUID id) {
    return ResponseEntity.ok(userUseCase.findUserById(id));
  }

  @PutMapping("/{id}")
  public ResponseEntity<?> updateUser(@PathVariable UUID id, @RequestBody User user) {
    return ResponseEntity.ok(userUseCase.updateUser(id, user));
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<?> deleteUser(@PathVariable UUID id) {
    userUseCase.deleteUser(id);
    return ResponseEntity.noContent().build();
  }
}
