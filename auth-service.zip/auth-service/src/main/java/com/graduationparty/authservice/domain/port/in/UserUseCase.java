package com.graduationparty.authservice.domain.port.in;

import com.graduationparty.authservice.adapter.out.response.Page;
import com.graduationparty.authservice.adapter.out.response.UserDTO;
import com.graduationparty.authservice.domain.model.AccessToken;
import com.graduationparty.authservice.domain.model.User;
import java.util.UUID;

/**
 * Interface que define os casos de uso do domínio relacionados ao gerenciamento de usuários.
 * Representa a porta de entrada na arquitetura hexagonal, especificando as operações que o núcleo
 * da aplicação oferece para interagir com usuários.
 */
public interface UserUseCase {

  /**
   * Cria um novo usuário no sistema de autenticação externo (ex.: Keycloak).
   *
   * @param user Dados do usuário a ser criado.
   * @return O usuário criado, incluindo o ID gerado pelo sistema externo.
   * @throws IllegalArgumentException se os dados do usuário forem inválidos.
   * @throws RuntimeException se houver falha na criação do usuário no sistema externo.
   */
  User createUser(User user);

  /**
   * Autentica um usuário com base em suas credenciais, retornando um token JWT.
   *
   * @param username Nome de usuário.
   * @param password Senha do usuário.
   * @return Token JWT gerado pelo sistema de autenticação.
   * @throws IllegalArgumentException se as credenciais forem inválidas ou vazias.
   * @throws RuntimeException se a autenticação falhar (ex.: credenciais incorretas).
   */
  AccessToken authenticate(String username, String password);

  /**
   * Busca um usuário pelo seu identificador único.
   *
   * @param id Identificador do usuário (UUID).
   * @return O usuário encontrado.
   * @throws IllegalArgumentException se o ID for nulo.
   * @throws RuntimeException se o usuário não for encontrado.
   */
  UserDTO findUserById(UUID id);

  Page<UserDTO> findAllUsers(int page, int size);

  /**
   * Atualiza os dados de um usuário existente.
   *
   * @param id Identificador do usuário (UUID).
   * @param user Dados atualizados do usuário.
   * @return O usuário atualizado.
   * @throws IllegalArgumentException se o ID ou os dados do usuário forem inválidos.
   * @throws RuntimeException se o usuário não for encontrado ou a atualização falhar.
   */
  User updateUser(UUID id, User user);

  /**
   * Remove um usuário do sistema.
   *
   * @param id Identificador do usuário (UUID).
   * @throws IllegalArgumentException se o ID for nulo.
   * @throws RuntimeException se a remoção falhar.
   */
  void deleteUser(UUID id);
}
