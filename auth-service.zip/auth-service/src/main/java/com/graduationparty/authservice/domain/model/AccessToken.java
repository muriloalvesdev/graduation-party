package com.graduationparty.authservice.domain.model;

public record AccessToken(String accessToken) {}
