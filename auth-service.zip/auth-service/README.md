# Auth Service

Este microserviço faz parte do projeto Graduation Party Manager e é responsável pela criação, autenticação e gerenciamento de usuários utilizando o Keycloak.

## Funcionalidades

- Cadastro e autenticação de usuários via Keycloak.
- Gerenciamento de usuários (listagem, busca, atualização e remoção) realizado através do Keycloak Admin Client.
- Validação dos tokens JWT emitidos pelo Keycloak utilizando o Spring Security como OAuth2 Resource Server.
- Logs de requisições (IP, URI, usuário, requestID).
- Documentação da API com Swagger/OpenAPI.
- Arquitetura hexagonal, com separação entre adaptadores de entrada e lógica de negócio.
- Testes unitários e de integração.

## Tecnologias Utilizadas

- Java 17
- Spring Boot 3.2.4
- Spring Security com OAuth2 Resource Server
- Keycloak Admin Client
- Springdoc OpenAPI
- Lombok

## Pré-requisitos

- JDK 17
- Maven 3.6+
- Instância do Keycloak (por exemplo, via Docker)

## Configuração do Keycloak

1. Inicie o Keycloak (por exemplo, usando Docker).
2. Crie um realm chamado `graduation-realm`.
3. Crie um client chamado `auth-service` e configure o secret conforme definido em `application.properties`.
4. Configure um usuário administrador para utilizar o Keycloak Admin Client (as credenciais devem estar definidas nas propriedades: `keycloak.admin.username`, `keycloak.admin.password` e `keycloak.admin.client-id`).

## Como Executar

1. Clone o repositório:
   ```bash
   git clone <repository-url>
